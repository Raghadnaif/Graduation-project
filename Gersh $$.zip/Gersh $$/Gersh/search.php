

   <?php
    $key = ''; 
if( isset( $_GET['key'])) {
    $key = $_GET['key']; 
} 
    $array = array();
    $con=mysqli_connect("localhost","root","","testgersh");
    $query=mysqli_query($con, "select * from customer where fname LIKE '%{$key}%' or lname LIKE '%{$key}%' or email LIKE '%{$key}%'");
    while($row=mysqli_fetch_assoc($query))
    {
      $array[] = $row['fname']." ".$row['lname']." ".$row['email'] ;
	  $a[] = $row['email'] ;
    }
    echo json_encode($array);
    mysqli_close($con);
	////////////////////////////////////////////////
	if( isset( $_POST['submit']))
	{
		 include_once 'DB.inc.php';		
	
         $name = $_POST['typeahead'] ; 
		 $parts=explode(" ", $name);
          
		  $fname=$parts[0];
		  $lname=$parts[1];
		  $email=$parts[2];
		  
         $query="select * from customer where fname='$fname' and lname='$lname' and email='$email' ";
	     $result=mysqli_query($con,$query);

//while ($row=mysqli_fetch_array($result)) {

  //   if($fname== $row['fname'] and $lname== $row['lname'] and $email== $row['email'] ){
     
//echo "<script>{document.location.href='search_result.php?email=".$row['email']."'};</script>";}}

	
	
	}
	////////////////////////////////////////////////////
?>



