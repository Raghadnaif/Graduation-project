<?php

if (isset($_GET['subscribe'])){

    $subscribe = $_GET['subscribe'];

    $msg = $subscribe." : You will keep in touch about news from us :) ";
}


    $connect = mysqli_connect("localhost","root","","flowerbank");

    if (isset($_GET['id'])){

        $id = $_GET['id'];

        $delete = "DELETE FROM cart WHERE id = '$id'";
        mysqli_query($connect,$delete);


    }

    $sql = "SELECT * FROM cart";

    $query = mysqli_query($connect,$sql);




    //Variables to store errors
    $name_error = $email_error = $address_error = $phone_error = "";
    //Variables to store user information
    $name = $email = $phone = $address = "";

    //If user clicks on submit button
    if ($_SERVER['REQUEST_METHOD'] == "POST"){

        $name = $_POST['name']; // get name from input name
        $email = $_POST['email']; // get email from input email

        $phone = $_POST['phone']; // get phone from input phone

        $address = $_POST['address']; //get address from input address

        if(empty($name)){ //if name is empty

            //store error hint in  $name_error variable
            $name_error = "Please enter your name ";
        }

        if (empty($email)){ //if email is empty
            //store error hint in $email_error variable
            $email_error = "Please enter your email ";
        }

        if (empty($phone)){ //if phone is empty
            //Store error hint in $phone_error variable
            $phone_error = "Please enter your phone ";

        }

        if(empty($address)){ // if address in empty
            //store error hint in $address_error variable
            $address_error = "Please enter your address";
        }

        //if all errors hints still empty its's mean user has entered all inputs
        if($name_error == "" && $email_error == "" && $phone_error == "" && $address_error == "" ){

            //INSERT TO DATA BASE

           if ($query->num_rows > 0 ){

               $insert = "INSERT INTO orders VALUES(null,'$name','$email','$phone','$address')";

               $query2 = mysqli_query($connect,$insert);
               $success = "We will contact you soon to deliver your order thanks :)";
               $name = $email = $phone = $address = "";

           }else{
               $name = $email = $phone = $address = "";
               $error = "You cart is empty  choose product to add ";
           }


        }
    }




?>
<!DOCTYPE html>
<html>
    <head>
		<link href="./css/Header.css" rel="stylesheet" type="text/css">
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
      <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script><!--imprtent-->
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script><!--imprtent-->
	</head>
	
    <body data-spy="scroll" data-target="#myScrollspy">
	<header class="THeader">
	<table>
  <tr>
    <th><img src="images/home-icon.png" class="home-icon" ></th>
    <th class="headertop1">The Flower Bank Instant</th> 
	<th style="color: #586077;">'delivery flower store offers'</th>
    <th><p class="headertop2">Today Only - Free Delivery</p></th>
	<th><img src="images/cart-icon.png"></th>
  </tr>
  </table>
    <img src="images/Border-Line.png" class="home-icon" width="1240">
	<table>
  <tr>
    <th><img src="images/logo.png" class="home-icon" ></th>
  </tr>
  </table>
  <center>
  <nav class="secondary_header" id="myScrollspy" >
      <ul class="nav nav-pills nav-stacked">
        <li ><a style="color:#f66875;" href="index.php">HOME</a></li>
        <li ><a style="color:#f66875;" href="index.php#section1" >FRESH</a></li>
        <li ><a style="color:#f66875;" href="index.php#section2">SERVICES</a></li>
        <li><a style="color:#f66875;" href="Product.php">PRODUCT</a></li>
        <li><a style="color:#f66875;" href="Mycart.php">CART</a></li>
        <li><a style="color:#f66875;" href="Contact.php">CONTACT</a></li>
		<li><a style="color:#f66875;" href="Aboutus.php">ABOUTUS</a></li>
      </ul>
    </nav>
	</center>
	<img src="images/Border-Line.png" class="home-icon" width="1240">
	 </header>
    <?php

    if (isset($msg)){

        echo "<h4 class='title head-title'>$msg</h4>";
    }
    ?>
  <div class="home-container">


      <div class="user-info">

          <form action="" method="post">
              <?php if (isset($success)):?>

                  <div class="group">
                        <span class="success"><?php echo  $success; ?></span>
                  </div>
              <?php endif;?>
               <?php if (isset($error)): ?>
                  <div class="group">
                      <div class="group">
                          <span class="error"><?php echo  $error; ?></span>
                      </div>
                  </div>
                <?php endif; ?>
              <div class="group">
                  <h3 class="head-title">User Information </h3>
              </div>
              <div class="group">
                  <label for="fullname">Full name  <span class="error"><?php echo $name_error;?><!-- print errors --></span> </label>
                  <input class="control" type="text" placeholder="Enter your name... " id="fullname" value="<?php echo $name;?>" name="name">
              </div>
              <div class="group">
                  <label for="email">Email <span class="error"><?php echo $email_error;?></span></label>
                  <input  class="control" type="email" id="email" placeholder="Enter your  email ....." value="<?php echo $email?>" name="email">
              </div>
              <div class="group">
                  <label for="phone">Phone <span class="error"><?php echo  $phone_error;?></span></label>
                  <input class="control" type="number" id="phone" placeholder="Enter phone number...." name="phone" value="<?php echo $phone;?>">
              </div>
              <div class="group">
                  <label for="address">Address <?php echo $address_error;?></label>
                  <input  class="control" type="text" name="address" id="address" placeholder="Enter your address...." value="<?php echo $address;?>">
              </div>

              <input class="button" type="submit" name="submit" value="Submit">
          </form>

      </div>
      <div class="products-list">
          <h3 class="head-title">Products List </h3>
          <div class="products-table-area">
              <table class="products-table">
                  <tr>
                      <th>Quantity</th>
                      <th>Name</th>
                      <th>Price</th>
                      <th>Remove</th>
                  </tr>
                  <?php

                    while($row = mysqli_fetch_array($query)){


                        echo "<tr>
                                     <td>{$row['quantity']}</td>   
                                     <td>{$row['name']}</td>   
                                     <td>{$row['price']} SAR</td>  
                                     <td><button onclick='location.href=\"?id={$row['id']}\"'>Delete</button></td> 
                               </tr>";

                    }


                  ?>


              </table>
          </div>

      </div>


  </div>


<br>
<br>
<br>
<br>
<br>
<footer class="THeader">
<div class="containerFresh">
  <img src="images/Footer.png" width="70%">
<div "><nav id="mune" class="Foot">
      <ul> BROWSE
         <li><a style="color:#f66875;" href="index.php">HOME</a></li></li>
		<li ><a style="color:#f66875;" href="index.php#section1" >FRESH ARRIVALS</a></li>
        <li ><a style="color:#f66875;" href="index.php#section2">SERVICES</a></li>
        <li><a style="color:#f66875;" href="Product.php">PRODUCT</a></li>
        <li><a style="color:#f66875;" href="Mycart.php">My CART</a></li>
        <li><a style="color:#f66875;" href="Contact.php">CONTACT</a></li>
		<li><a style="color:#f66875;" href="Aboutus.php">ABOUT US</a></li>
      </ul>
    </nav></div>


<div><a href="https://www.facebook.com/" class="fa fa-facebook"></a></div>
<div><a href="https://twitter.com/" class="fa fa-twitter"></a></div>
<div class="fa Subscribe">
<input type="email" name="emailaddress" value="YourEmail@exmple.com" id="email-sub" ><br><br>
    <button class="BTN PRODUCT" onclick="location.href='?subscribe='+document.getElementById('email-sub').value;">Subscribe</button></div>
<div>&copy; Copyrights 2018. All rights reserved.</div>
<div class="copy">Developer by Arwa A, Arwa Y, Hajar, Shahad</div>		
</div>
</footer>

    </body>
	
</html>