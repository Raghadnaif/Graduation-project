<?php

    if (isset($_GET['subscribe'])){

        $subscribe = $_GET['subscribe'];

        $msg = $subscribe." : You will keep in touch about news from us :) ";
    }


?>

<!DOCTYPE html>
<html>
    <head>
		<link href="css/Header.css" rel="stylesheet" type="text/css">
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
      <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script><!--imprtent-->
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script><!--imprtent-->
	</head>
	
    <body data-spy="scroll" data-target="#myScrollspy">
	<header class="THeader">
	<table>
  <tr>
    <th><img src="images/home-icon.png" class="home-icon" ></th>
    <th class="headertop1">The Flower Bank Instant</th> 
	<th style="color: #586077;">'delivery flower store offers'</th>
    <th><p class="headertop2">Today Only - Free Delivery</p></th>
	<th><img src="images/cart-icon.png"></th>
  </tr>
  </table>
    <img src="images/Border-Line.png" class="home-icon" width="1240">
	<table>
  <tr>
    <th><img src="images/logo.png" class="home-icon" ></th>
  </tr>
  </table>
  <center>
  <nav class="secondary_header" id="myScrollspy" >
      <ul class="nav nav-pills nav-stacked">
        <li ><a style="color:#f66875;" href="index.php">HOME</a></li>
        <li ><a style="color:#f66875;" href="index.php#section1" >FRESH</a></li>
        <li ><a style="color:#f66875;" href="index.php#section2">SERVICES</a></li>
        <li><a style="color:#f66875;" href="Product.php">PRODUCT</a></li>
        <li><a style="color:#f66875;" href="Mycart.php">CART</a></li>
        <li><a style="color:#f66875;" href="Contact.php">CONTACT</a></li>
		<li><a style="color:#f66875;" href="Aboutus.php">ABOUTUS</a></li>
      </ul>
    </nav>
	</center>
	<img src="images/Border-Line.png" class="home-icon" width="1240">
	 </header>
	<div class="container">
    <?php

        if (isset($msg)){

            echo "<h4 class='title head-title'>$msg</h4>";
        }
    ?>
  <img src="images/Banner%20bg.png" alt="Banner" style="width:100%;">
  <div class="centered1" ><h1>About us</h1></div>
<div class="centered2"><img src="images/Flowers%20green.png" width="80%" ></div>
</div>
<br>
<br>
<br>
<div>
<img src="images/About us.png" class="contact" width="50%" >
<br>
<br>
<footer class="THeader">
<div class="containerFresh">
  <img src="images/Footer.png" width="70%">
<div "><nav id="mune" class="Foot">
      <ul> BROWSE
       <li><a style="color:#f66875;" href="index.php">HOME</a></li></li>
		<li ><a style="color:#f66875;" href="index.php#section1" >FRESH ARRIVALS</a></li>
        <li ><a style="color:#f66875;" href="index.php#section2">SERVICES</a></li>
        <li><a style="color:#f66875;" href="Product.php">PRODUCT</a></li>
        <li><a style="color:#f66875;" href="Mycart.php">My CART</a></li>
        <li><a style="color:#f66875;" href="Contact.php">CONTACT</a></li>
		<li><a style="color:#f66875;" href="Aboutus.php">ABOUT US</a></li>
      </ul>
    </nav></div>
<div><a href="https://www.facebook.com/" class="fa fa-facebook"></a></div>
<div><a href="https://twitter.com/" class="fa fa-twitter"></a></div>
<div class="fa Subscribe">
<input type="email" name="emailaddress" value="YourEmail@exmple.com" id="email-sub"><br><br>
<button class="BTN PRODUCT" onclick="location.href='?subscribe='+document.getElementById('email-sub').value;">Subscribe</button></div>
<div>&copy; Copyrights 2018. All rights reserved.</div>
<div class="copy">Developer by Arwa A, Arwa Y, Hajar, Shahad</div>		
</div>
</footer>

    </body>
	
</html>