<?php

if (isset($_GET['subscribe'])){

    $subscribe = $_GET['subscribe'];

    $msg = $subscribe." : You will keep in touch about news from us :) ";
}


?>
<!DOCTYPE html>
<html>
    <head>
		<link href="css/Header.css" rel="stylesheet" type="text/css">
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
      <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script><!--imprtent-->
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script><!--imprtent-->
	</head>
	
    <body data-spy="scroll" data-target="#myScrollspy">
	<header class="THeader">
	<table>
  <tr>
    <th><img src="images/home-icon.png" class="home-icon" ></th>
    <th class="headertop1">The Flower Bank Instant</th> 
	<th style="color: #586077;">'delivery flower store offers'</th>
    <th><p class="headertop2">Today Only - Free Delivery</p></th>
	<th><img src="images/cart-icon.png"></th>
  </tr>
  </table>
    <img src="images/Border-Line.png" class="home-icon" width="1240">
	<table>
  <tr>
    <th><img src="images/logo.png" class="home-icon" ></th>
  </tr>
  </table>
  <center>
  <nav class="secondary_header" id="myScrollspy" >
      <ul class="nav nav-pills nav-stacked">
        <li ><a style="color:#f66875;" href="index.php">HOME</a></li>
        <li ><a style="color:#f66875;" href="index.php#section1" >FRESH</a></li>
        <li ><a style="color:#f66875;" href="index.php#section2">SERVICES</a></li>
        <li><a style="color:#f66875;" href="Product.php">PRODUCT</a></li>
        <li><a style="color:#f66875;" href="Mycart.php">CART</a></li>
        <li><a style="color:#f66875;" href="Contact.php">CONTACT</a></li>
		<li><a style="color:#f66875;" href="Aboutus.php">ABOUTUS</a></li>
      </ul>
    </nav>
	</center>
	<img src="images/Border-Line.png" class="home-icon" width="1240">
	 </header>
	<div class="container">
    <h1 class="head-title title">Welcome TO OUR WEBSITE :) </h1>
        <?php

        if (isset($msg)){

            echo "<h4 class='title head-title'>$msg</h4>";
        }
        ?>

        <img src="images/Banner%20bg.png" alt="Banner" style="width:100%;">
  <div class="centered1"><h1>THE LARGEST COLLECTION OF<br> FRESH FLOWERS FOR EVERY<br> OCCASION!</h1>
<br>
We work with every kind of qusality florists because <br>
this is very important for our sphere of work.</div>
<div class="centered2"><img src="images/Banner%20Flowers.png" width="140%" ></div>
</div>
<br>
<br>
<br>
<br>
<br>
<br>
<center><h1 class="texth" id="section1">FRESH ARRIVALS</h1></center>
<div class="containerFresh">
  <img src="images/light-bg.png" width="1000">
 <div class="texthh"><h4>A little band of fresh flowers right from the field</h4></div>
<div class="centered3"><img src="images/Flowers%20pot%204.png"></div>
<div class="centered4"><img src="images/Flowers%20pot%203.png"></div>
<div class="centered5"><img src="images/Flowers%20pot%202.png"></div>
<div class="centered6"><img src="images/Flowers%20pot%201.png"></div>
<div class="centered7">
<h5 >Flowers of Kararina
<br>
VALENTINE FLOWERS
<br>
<br\ style="color: #f66875;">
129.90 SAR</h5></div>

<div class="centered8">
<h5 >Flowers of Kararina
<br>
VALENTINE FLOWERS
<br>
<br\ style="color: #f66875;">
129.90 SAR</h5></div>

<div class="centered9">
<h5 >Flowers of Kararina
<br>
VALENTINE FLOWERS
<br>
<br\ style="color: #f66875;">
129.90 SAR</h5></div>

<div class="centered10">
<h5 >Flowers of Kararina
<br>
VALENTINE FLOWERS
<br>
<br\ style="color: #f66875;">
129.90 SAR</h5></div>

</div>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<center>
<button class="BTN PRODUCT favorit_style"  type="button"><a style="color:white;" href="Product.php">PRODUCT</a></button>
</center>
<br>
<div class="Section" id="section2">
  <img src="images/Services%20Section.png" width="100%">
<div><button class="BTN PRODUCT Services"><a style="color:white;" href="Mycart.php">My Cart</a></button></div>
</div>
<footer class="THeader">
<div class="containerFresh">
  <img src="images/Footer.png" width="70%">
<div><nav id="mune" class="Foot">
      <ul> BROWSE
        <li><a style="color:#f66875;" href="index.php">HOME</a></li></li>
		<li ><a style="color:#f66875;" href="index.php#section1" >FRESH ARRIVALS</a></li>
        <li ><a style="color:#f66875;" href="index.php#section2">SERVICES</a></li>
        <li><a style="color:#f66875;" href="Product.php">PRODUCT</a></li>
        <li><a style="color:#f66875;" href="Mycart.php">My CART</a></li>
        <li><a style="color:#f66875;" href="Contact.php">CONTACT</a></li>
		<li><a style="color:#f66875;" href="Aboutus.php">ABOUT US</a></li>
      </ul>
    </nav></div>
<div><a href="https://www.facebook.com/" class="fa fa-facebook"></a></div>
<div><a href="https://twitter.com/" class="fa fa-twitter"></a></div>

<div class="fa Subscribe">
<input type="email" name="emailaddress" value="YourEmail@exmple.com"  id="email-sub"><br><br>
    <button class="BTN PRODUCT" onclick="location.href='?subscribe='+document.getElementById('email-sub').value;">Subscribe</button></div>
	
<div>&copy; Copyrights 2018. All rights reserved.</div>
<div class="copy">Developer by Arwa A, Arwa Y, Hajar, Shahad</div>		
</div>
</footer>

    </body>
	
</html>