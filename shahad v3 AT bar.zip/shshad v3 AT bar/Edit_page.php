<!DOCTYPE html>
<?php
include('db.class.php'); // call db.class.php
$mydb = new db(); // create a new object, class db()
?>

 <?php include_once 'DB.inc.php';?>
<html >
<head>
	<title>Edit page</title>
	<link rel="icon" type="image/ico" href="images/logo1.png" />
    <meta name="keywords" content="">
	<meta name="description" content="">
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=Edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<!-- stylesheet css -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" href="css/font-awesome.min.css">
	<link rel="stylesheet" href="css/nivo-lightbox.css">
	<link rel="stylesheet" href="css/nivo_themes/default/default.css">
	<link rel="stylesheet" href="css/templatemo-style.css">	<link rel="stylesheet" href="css/font-awesome.min.css">
	<link rel="stylesheet" href="css/nivo-lightbox.css">
	<link rel="stylesheet" href="css/nivo_themes/default/default.css">
	<link rel="stylesheet" href="css/templatemo-style.css">
	<!-- google web font css -->
	<link href='http://fonts.googleapis.com/css?family=Montserrat:400,700' rel='stylesheet' type='text/css'>
    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
    <script src="../js/typeahead.min.js"></script>
    <script>
	
	    <script>
    $(document).ready(function(){
    $('input.typeahead').typeahead({
        name: 'typeahead',
        remote:'search.php?key=%QUERY',
        limit : 10
    });
});
    </script>
<script type="text/javascript">

$(document).ready(function(){

 load_data();

 function load_data(query)
 {
  $.ajax({
   url:"fetch.php",
   method:"POST",
   data:{query:query},
   success:function(data)
   {
    $('#result').html(data);
   }
  });
 }
 
 $('#search_text').keyup(function(){
  var search = $(this).val();
  if(search != '')
  {
   load_data(search);
  }
  else
  {
   load_data();
  }
 });
});


function showRow(row)
{
	var x=row.cells;
	document.getElementById("fname").value = x[0].innerHTML;
	document.getElementById("lname").value = x[1].innerHTML;
	document.getElementById("email").value = x[2].innerHTML;
}




</script>	
<!-- navigation -->
</head>
<body>
		<div class="navbar navbar-default navbar-static-top" role="navigation">
		<div class="navbar-header">
			<button class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
				<span class="icon icon-bar"></span>
				<span class="icon icon-bar"></span>
				<span class="icon icon-bar"></span>
			</button>
			<a href="#" class="navbar-brand"><img src="images/logo.png" class="img-responsive" alt="logo"></a>
		</div>
		<div class="collapse navbar-collapse">
			<ul class="nav navbar-nav navbar-right">
				<li><a href="index.html" class="active">HOME</a></li>
				<li><a href="about.html">ABOUT US</a></li>
                <li class="dropdown">
                <a href="Services_customer.html" class="dropbtn">CUSTOMERS</a>
                <div class="dropdown-content">
                <a href="Services_customer.html">Services</a>
                <a href="Fees_customer.html">Fess</a>
                </div>	
                <li class="dropdown">
                <a href="Services_Merchants.html" class="dropbtn">MERCHANTS</a>
                <div class="dropdown-content">
                <a href="Services_Merchants.html">Services</a>
                <a href="Fees_‏‏Merchants.html">Fess</a>
                </div>			
				<li><a href="Support.html">SUPPORT</a></li>
			</ul>
		</div>
	</div>
	<br><br>
	
		
		<h2 id ="ADD">Edit Page </h2>
	<div class="panel-body"> 
	<ul class="nav nav-tabs">
	</ul></br>
		<div class="col-sm-6">
		<div class=".col-md-6">
          <div class="panel panel-default">
          <div class="bs-example">
           <div class="input-group">
            <span class="input-group-addon">Search</span>
            <input type="text" name="search_text" id="search_text" placeholder="Search by " class="form-control" />
           </div>
	      </div>
         </div>
       </div>
			
				<table class="table table-striped table-hover" id="main">
				<thead>
				  <tr>
					<th>First Name</th>
					<th>Last Name</th>
					<th>Email</th>
				</thead>
				<tbody id="result">
				</tbody>
				</table>
		<div class="paging_link"></div>
		</div>
		<div class="col-sm-6">
			<form class="form-horizontal" method="post" action="Edit_php.php" enctype="multipart/form-data">
		  <div class="form-group">
				<label class="control-label col-sm-3">First Name:</label>
				<div class="col-sm-9">
				  <input type="text" class="form-control" id="fname" required placeholder="First Name" name="fname" >
				</div>
			  </div>
			  
			  
			  <div class="form-group">
				<label class="control-label col-sm-3">Last Name:</label>
				<div class="col-sm-9"> 
				  <input type="text" class="form-control" id="lname" required placeholder="Last Name" name="lname">
				</div>
			  </div>
			  
			  <div class="form-group">
				<label class="control-label col-sm-3">Email:</label>
				<div class="col-sm-9"> 
				  <input type="email" class="form-control" id="email" required placeholder="email" name="email">
				</div>
			  </div>
			  
			    <div class="form-group">
				<label class="control-label col-sm-3">Customer image:</label>
				<div class="col-sm-9">
				   <input type="file" name="pic" accept="image/*">
				</div>
			  </div>
			  <br><br>
			  <div class="form-group"> 
				<div class="col-sm-offset-3 col-sm-9">
				  <button type="submit" class="btn btn-default" name="Edit">Edit</button>
			
				  <a href="php/admin.php"><button type="button" class="btn btn-default" name="Back">Back</button></a>
				</div>
			  </div>
     	 </form>
      </div>
     </div>

 <br><br>
<div class="copyright">
	<div class="container">
		<div class="row">
			<div class="col-md-6 col-sm-6">
				<p>Copyright © 2019 Gersh pay </p>
			</div>
			<div class="col-md-6 col-sm-6">
				<ul class="social-icons">
					<li><a href="#" class="fa fa-facebook"></a></li>
					<li><a href="#" class="fa fa-twitter"></a></li>
					<li><a href="#" class="fa fa-dribbble"></a></li>
					<li><a href="#" class="fa fa-pinterest"></a></li>
					<li><a href="#" class="fa fa-behance"></a></li>
					<li><a href="#" class="fa fa-envelope-o"></a></li>
				</ul>
			</div>
		</div>
	</div>
</div>


</body>

		<!-- copyright section -->

<!-- Footer -->



<!-- javascript js -->	
<script src="js/jquery.js"></script>
<script src="js/bootstrap.min.js"></script>	
<script src="js/nivo-lightbox.min.js"></script>
<script src="js/custom.js"></script>

</html>