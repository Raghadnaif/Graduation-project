<!DOCTYPE html>
<html lang="en">
<head>
	<title>Gersh pay</title>
	<link rel="icon" type="image/ico" href="images/logo1.png" />
    <meta name="keywords" content="">
	<meta name="description" content="">
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=Edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<!-- stylesheet css -->
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" href="css/font-awesome.min.css">
	<link rel="stylesheet" href="css/nivo-lightbox.css">
	<link rel="stylesheet" href="css/nivo_themes/default/default.css">
	<link rel="stylesheet" href="css/templatemo-style.css">
	<!-- google web font css -->
	<link href='http://fonts.googleapis.com/css?family=Montserrat:400,700' rel='stylesheet' type='text/css'>
	<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false);
function hideURLbar(){ window.scrollTo(0,1); } </script>

  
 <?php include_once 'DB.inc.php';?>
 <?php  include_once 'login-php.php'; ?>

</head>
<body>
	
<!-- navigation -->

	<div class="container">
		<div class="navbar navbar-default navbar-static-top" role="navigation">
		<div class="navbar-header">
			<button class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
				<span class="icon icon-bar"></span>
				<span class="icon icon-bar"></span>
				<span class="icon icon-bar"></span>
			</button>
			<a href="#" class="navbar-brand"><img src="images/logo.png" class="img-responsive" alt="logo"></a>
		</div>
		<div class="collapse navbar-collapse">
			<ul class="nav navbar-nav navbar-right">
				<li><a href="index.html" >HOME</a></li>
				<li><a href="about.html">ABOUT US</a></li>
                <li class="dropdown">
                <a href="Services_customer.html" class="dropbtn">CUSTOMERS</a>
                <div class="dropdown-content">
                <a href="Services_customer.html">Services</a>
                <a href="Fees_customer.html">Fess</a>
                </div>	
                <li class="dropdown">
                <a href="Services_Merchants.html" class="dropbtn">MERCHANTS</a>
                <div class="dropdown-content">
                <a href="Services_Merchants.html">Services</a>
                <a href="Fees_‏‏Merchants.html">Fess</a>
                </div>			
				<li><a href="Support.html">SUPPORT</a></li>
			</ul>
		</div>
	</div>
</div>		
<ul class="nav navbar-nav navbar-right">
        <li><a href="log_in.html"><span class="glyphicon glyphicon-log-in"></span> Login</a></li>
		<li><a href="SignUp.html"><span class="glyphicon glyphicon-log-out"></span> SignUp</a></li>
      </ul>

	<div class="header-w3l">
	</div>
	<br><br><br>
<!--//header-->
<!--login-->
<div class="login-agileits">
	<h2 class="login-head">Login</h2>
		<div class="login-main">	
			<form action="#" method="post">
				
				<input placeholder="Email" name="Email" class="mail" type="text" required="">
					<span class="icon44"><i class="fa fa-envelope" aria-hidden="true"></i></span><br>

				<input  placeholder="Password" name="Password" class="pass" type="password" required="">
					<span class="icon55"><i class="fa fa-unlock" aria-hidden="true"></i></span><br>
					 <a href="forget.html">Forget your password?</a><br>
				    <a href="loginphp.php">  <input type="submit" name= "submit" value="login"></a>


			</form>

		</div>
		<br><br>

		<div class="clear"></div>
</div>
<!--//login-->


			
		</div>
	</div>
</div>		

<footer class="page-footer font-small indigo">

    <div class="container">
      <div class="row text-center d-flex justify-content-center pt-7 mb-5">
        <div class="col-md-3 mb-3">
          <h6 class="text-uppercase font-weight-bold">
            <a href="index.html">Home</a>
          </h6>
        </div>
        <div class="col-md-2 mb-3">
          <h6 class="text-uppercase font-weight-bold">
            <a href="about.html">About us </a>
          </h6>
        </div>
        <div class="col-md-2 mb-3">
          <h6 class="text-uppercase font-weight-bold">
            <a href="Customers.html"> Customer </a>
          </h6>
        </div>
       
        <div class="col-md-2 mb-3">
          <h6 class="text-uppercase font-weight-bold">
            <a href="Merchants.html">Merchants</a>
          </h6>
        </div>
       
        <div class="col-md-2 mb-3">
          <h6 class="text-uppercase font-weight-bold">
            <a href="Support.html">Support</a>
          </h6>
        </div>
      </div>
   
      </div>
   
        </div>

      </div>

    </div>
	
	


  </footer>
<div class="copyright">
	<div class="container">
		<div class="row">
			<div class="col-md-6 col-sm-6">
				<p>Copyright © 2019 Gersh pay </p>
			</div>
			<div class="col-md-6 col-sm-6">
				<ul class="social-icons">
					<li><a href="#" class="fa fa-facebook"></a></li>
					<li><a href="#" class="fa fa-twitter"></a></li>
					<li><a href="#" class="fa fa-dribbble"></a></li>
					<li><a href="#" class="fa fa-pinterest"></a></li>
					<li><a href="#" class="fa fa-behance"></a></li>
					<li><a href="#" class="fa fa-envelope-o"></a></li>
				</ul>
			</div>
		</div>
	</div>
</div>


<!-- javascript js -->	
<script src="js/jquery.js"></script>
<script src="js/bootstrap.min.js"></script>	
<script src="js/nivo-lightbox.min.js"></script>
<script src="js/custom.js"></script>

</body>
</html>