 <?php include_once 'DB.inc.php'; 
   session_start();
   if (isset($_POST["submit"])){
		if(empty($_POST['email'])|| empty ($_POST['password'] )){
			
			echo "<script>if(confirm('Email or password is invalid ')){document.location.href='log_in.php'};</script>";
			
		}
		else{
	
    $Email =$_POST["email"] ;   
    $Password =$_POST["password"] ; 
    
	$query="select * from customer where email='$Email' and password='$Password' ";
	$exe_query=mysqli_query($con,$query);
	$found_num_rows=mysqli_num_rows($exe_query);
	
	
	if($found_num_rows==1)
	{
		
		
	
		 $row = mysqli_fetch_assoc($exe_query); 
		 $_SESSION['email'] = $row['email'];
       // $_SESSION['username'] = $row['username'];
      if($row['k'] == 1){
	    echo "<script>{document.location.href='admin_profile.php?email=".$row['email']."'};</script>";
      }else if($row['k'] == 2 ){
        echo "<script>{document.location.href='merchant_profile.php?email=".$row['email']."'};</script>";
      }else if($row['k'] == 3 ){
        echo "<script>{document.location.href='customer_profile.php?email=".$row['email']."'};</script>";
      }
		
	
	} else{
		
		echo "<script>if(confirm('Email or password is not correct please try again')){document.location.href='log_in.php'};</script>";
	}
	mysqli_close($con);
		}
}
	
?>
