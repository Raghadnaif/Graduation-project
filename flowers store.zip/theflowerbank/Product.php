<?php

if (isset($_GET['subscribe'])){

    $subscribe = $_GET['subscribe'];

    $msg = $subscribe." : You will keep in touch about news from us :) ";
}


if (isset($_GET['name'])){


        $name = $_GET['name'];
        $price = $_GET['price'];



        $connect = mysqli_connect("localhost","root","","flowerbank");

        $sql1  = "SELECT * FROM cart WHERE name = '$name' ";

        $query1 = mysqli_query($connect,$sql1);


        if ($query1->num_rows > 0 ){

               $sql2 = "UPDATE cart SET price = price + '$price' ,quantity = quantity+1  WHERE name = '$name' ";

        }else{

            $sql2 = "INSERT INTO cart VALUES (NULL,'$name','1','$price')";

        }

        $query2 = mysqli_query($connect,$sql2);


        if ($query2) {

            header("location:Mycart.php");
        }

    }

?>
<!DOCTYPE html>
<html>
    <head>
		<link href="css/Header.css" rel="stylesheet" type="text/css">
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
      <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script><!--imprtent-->
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script><!--imprtent-->
	</head>
	
    <body data-spy="scroll" data-target="#myScrollspy">
	<header class="THeader">
	<table>
  <tr>
    <th><img src="images/home-icon.png" class="home-icon" ></th>
    <th class="headertop1">The Flower Bank Instant</th> 
	<th style="color: #586077;">'delivery flower store offers'</th>
    <th><p class="headertop2">Today Only - Free Delivery</p></th>
	<th><img src="images/cart-icon.png"></th>
  </tr>
  </table>
    <img src="images/Border-Line.png" class="home-icon" width="1240">
	<table>
  <tr>
    <th><img src="images/logo.png" class="home-icon" ></th>
  </tr>
  </table>
  <center>
  <nav class="secondary_header" id="myScrollspy" >
      <ul class="nav nav-pills nav-stacked">
        <li ><a style="color:#f66875;" href="index.php">HOME</a></li>
        <li ><a style="color:#f66875;" href="index.php#section1" >FRESH</a></li>
        <li ><a style="color:#f66875;" href="index.php#section2">SERVICES</a></li>
        <li><a style="color:#f66875;" href="Product.php">PRODUCT</a></li>
        <li><a style="color:#f66875;" href="Mycart.php">CART</a></li>
        <li><a style="color:#f66875;" href="Contact.php">CONTACT</a></li>
		<li><a style="color:#f66875;" href="Aboutus.php">ABOUTUS</a></li>
      </ul>
    </nav>
	</center>
	<img src="images/Border-Line.png" class="home-icon" width="1240">
	 </header>
	<!--here product-->
	<center><h1 style="color:#586077;" >Product</h1></center>
    <?php

    if (isset($msg)){

        echo "<h4 class='title head-title'>$msg</h4>";
    }
    ?>
<center><table border="1" cellpadding="5" cellspacing="5"  border-spacing: 5px;>

<tr>
<th colspan="4" style="color:#586077;" > Luxury Flowers</th>
</tr>
<tr>
<td><img src="images/3.jpg" width="128" height="128"></td>
<td><img src="images/3.jpg" width="128" height="128"></td>
<td><img src="images/4.jpg" width="128" height="128"></td>
<td><img src="images/5.jpg" width="128" height="128"></td>
</tr>
<tr>
<td style="color:#586077;">The Great Hugger </br>SAR 200</td>
<td style="color:#586077;">The Princess</br> SAR 250</td>
<td style="color:#586077;">The Pink Bloom</br> SAR 250</td>
<td style="color:#586077;">The Queen</br> SAR 280</td>
</tr>
<tr>
<td style="color:#586077;"><button onclick="location.href='?name=The Great Hugger&price=200'">Add to cart</button></td>
<td style="color:#586077;"><button onclick="location.href='?name=The Princess&price=250'">Add to cart</button></td>
<td style="color:#586077;"><button onclick="location.href='?name=The Pink Bloom&price=250'">Add to cart</button></td>
<td style="color:#586077;"><button onclick="location.href='?name=The Queen&price=280'">Add to cart</button></td>
</tr>
</table>
</center>
</br>
<center><table border="1" cellpadding="5" cellspacing="5"  border-spacing: 5px;>
<tr>
<th colspan="4"  style="color:#586077;"> Weeding bouquet  </th>
</tr>
<tr>
<td><img src="images/7.jpg" width="128" height="128"></td>
<td><img src="images/8.jpg" width="128" height="128"></td>
<td><img src="images/9.jpg" width="128" height="128"></td>
<td><img src="images/10.jpg" width="128" height="128"></td>

</tr>
<tr>
<td style="color:#586077;">The Bruch bouquet</br>SAR 300</td>
<td style="color:#586077;">The Brooch bouquet</br> SAR 340</td>
<td style="color:#586077;">The Boho bouquet</br> SAR 310</td>
<td style="color:#586077;">The One bouquet</br> SAR 330</td>
</tr>
<tr>
<td style="color:#586077;"><button onclick="location.href='?name=The Bruch bouquet&price=300'">Add to cart</button></td>
<td style="color:#586077;"><button onclick="location.href='?name=The Brooch bouquet&price=340'">Add to cart</button></td>
<td style="color:#586077;"><button onclick="location.href='?name=The Boho bouquet&price=310'">Add to cart</button></td>
<td style="color:#586077;"><button onclick="location.href='?name=The One bouquet&price=330'">Add to cart</button></td>
</tr>
</table>
</center>
<br>
<br>
<br>
<br>
<br>
<footer class="THeader">
<div class="containerFresh">
  <img src="images/Footer.png" width="70%">
<div "><nav id="mune" class="Foot">
      <ul> BROWSE
         <li><a style="color:#f66875;" href="index.php">HOME</a></li></li>
		<li ><a style="color:#f66875;" href="index.php#section1" >FRESH ARRIVALS</a></li>
        <li ><a style="color:#f66875;" href="index.php#section2">SERVICES</a></li>
        <li><a style="color:#f66875;" href="Product.php">PRODUCT</a></li>
        <li><a style="color:#f66875;" href="Mycart.html">My CART</a></li>
        <li><a style="color:#f66875;" href="Contact.php">CONTACT</a></li>
		<li><a style="color:#f66875;" href="Aboutus.php">ABOUT US</a></li>
      </ul>
    </nav></div>
<div><a href="https://www.facebook.com/" class="fa fa-facebook"></a></div>
<div><a href="https://twitter.com/" class="fa fa-twitter"></a></div>
<div class="fa Subscribe">
<input type="email" name="emailaddress" value="YourEmail@exmple.com" id="email-sub" ><br><br>
<button class="BTN PRODUCT" onclick="location.href='?subscribe='+document.getElementById('email-sub').value;">Subscribe</button></div>
<div>&copy; Copyrights 2018. All rights reserved.</div>
<div class="copy">Developer by Arwa A, Arwa Y, Hajar, Shahad</div>		
</div>
</footer>

    </body>
	
</html>